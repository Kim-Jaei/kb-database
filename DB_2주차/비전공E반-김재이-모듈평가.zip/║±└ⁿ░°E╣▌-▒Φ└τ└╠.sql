# 혹시 몰라서 sql script도 함께 제출합니다 :D

-- 1-1. city테이블에 대한 전체 내용을 출력
USE world2;
SELECT * FROM city;

-- 1-2. countrylanguage테이블에서 CountryCode가 ‘CHE’인 Language, Percentage컬럼 출력
SELECT Language, Percentage from countrylanguage
where CountryCode = 'CHE';

-- 1-3. city테이블에 다음 항목 데이터를 삽입
INSERT INTO city(id, name, countrycode, district, population)
values(null, 'Cairo', 'EGY', 'Cairo Governorate', 9500000);

-- 1-4. city 테이블에서 CountryCode가 'PNG'인 모든 행의 Name 열 값을 'GoodSite'로 변경
update city set name = 'GoodSite' where CountryCode = 'PNG';

-- 1-5. country 테이블에서 Name 열을 기준으로 내림차순으로 정렬하여 모든 컬럼을 출력
select * from country order by name desc;

-- 2-1. city테이블에서 Name 컬럼의 데이터를 모두 대문자로 변경하여 출력
select UPPER(name) as 'Name' from city;

-- 2-2. city테이블에서 ID 컬럼과 CountryCode 컬럼의 데이터를 결합하여 “4080-TKM”와 같이 출력
select concat('\"', id, '-', countrycode, '\"') from city;
select concat_ws('-', id, countrycode) from city;

-- 2-3. city테이블에서 District 컬럼 데이터(영문)의 글자수를 출력
select char_length(district) as '글자수' from city;

-- 2-4. city테이블에서 Population 컬럼의 평균값을 출력
select avg(population) from city;

-- 2-5. country테이블에서 Continent별 최대값 GNP값 출력
-- (출력 항목은 Continent 명, GNP 최대값. 출력 순서는 GNP 최대값의 오름차순)
select Continent, max(gnp) from country group by Continent order by max(gnp);

-- 3-1. city 테이블과 country 테이블을 CountryCode 컬럼과 Code 컬럼 기준으로 조인하고,
-- city의 Name과 conutry의 Name을 출력 하시오. (inner join문 이용)
select ci.name as 'city_name', co.name as 'country_name'
from city ci
inner join country co
on ci.countrycode = co.code;

-- 3-2. country테이블에서 모든 국가명을 출력하고 각 국가에서 사용되는 언어를 함께 출력
-- (사용 언어가 없는 경우 NULL 표시, outer join문 이용)
select c.name, ifnull(lang.language, 'null') as 'language'
from country c
left outer join countrylanguage lang
on c.code = lang.countrycode;

-- 3-3. city테이블에서 최대 인구를 가진 도시의 이름을 출력
-- (서브쿼리, MAX()함수 이용)
select name from city
where population = (select max(population) from city);